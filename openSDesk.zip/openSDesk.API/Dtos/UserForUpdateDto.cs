namespace openSDesk.API.Dtos
{
    public class UserForUpdateDto
    {
        public string Introduction { get; set; }
    }
}