namespace openSDesk.API.Dtos
{
    public class UserForSelectDto
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}