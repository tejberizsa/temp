namespace openSDesk.API.Dtos
{
    public class UserForTicketDetailDto
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}