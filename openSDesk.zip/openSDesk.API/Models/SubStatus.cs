namespace openSDesk.API.Models
{
    public class SubStatus
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}