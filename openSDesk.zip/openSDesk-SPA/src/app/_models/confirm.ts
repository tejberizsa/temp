export interface Confirm {
    id: string;
    confirmkey: string;
}
