export interface Category {
    id: number;
    text: string;
}
