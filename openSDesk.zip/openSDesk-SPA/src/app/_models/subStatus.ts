export interface SubStatus {
    id: number;
    text: string;
}
