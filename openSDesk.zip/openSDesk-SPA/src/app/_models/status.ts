export interface Status {
    id: number;
    text: string;
}
