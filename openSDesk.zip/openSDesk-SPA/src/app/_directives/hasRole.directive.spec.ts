/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HasRoleDirective } from './hasRole.directive';

describe('Directive: HasRole', () => {
  it('should create an instance', () => {
    const directive = new HasRoleDirective();
    expect(directive).toBeTruthy();
  });
});
